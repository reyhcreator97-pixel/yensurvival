<?= $this->extend('templates/admin/index'); ?>

<?= $this->section('page-content-admin'); ?>
<div class="container-fluid">

<!-- Page Heading -->
<h1 class="h3 mb-4 text-gray-800">Page Admin</h1>


</div>

<?= $this->endSection(); ?>